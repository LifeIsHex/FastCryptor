[*] Fast Cryptor 2.2.5 Build 18
===============================

[>] Note: Fast Cryptor comes with absolutely no guarantee. Use at your own risk.

===================================================================================================

[*] What is Fast Cryptor?

    Fast Cryptor is a file encryptor\decryptor for windows x64 and x32 architecture.
    Designed to be simple and user-friendly, yet powerful and portable. It uses AES 256 EAX algorithm.

===================================================================================================

[*] Version History

	[>] 2.2.5 Build 18 (2023-02-08)
	    [+] Now full Unicode support.
	    [+] Code Improvement.
	    [+] Optimized FileCryptor control. (handle errors)
	    [+] Updated GUI.
	    [+] Added show\hide password button. (password dialog)
	    [+] Added password input length limitation. (max 32 characters)
	    [+] Added a new button to abort the whole operation.
	    [-] Fixed TaskDialog hyperlink bug.
	    [-] Fixed the minimize button bug.
	    [-] Fixed the progress bar bug.
	    [-] Fixed the cancel operation bug. In case the password is wrong.
		
	[>] 2.1.1 Build 11 (2023-02-05)
	    [-] Fixed crash.

	[>] 2.1.1 Build 10 (2023-02-05)
	    [+] Drag and drop support.
	    [+] Added AES 256 EAX algorithm.
	    [+] Added Shredder Source File. (1 pass)
	    [+] Portable and light.

===================================================================================================